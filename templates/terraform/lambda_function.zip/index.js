var AWS = require('aws-sdk');
var sqs = new AWS.SQS();

const crypto = require('crypto');
const algorithm = 'aes-256-cbc'; //Using AES encryption
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);
//var queueURL = "https://sqs.ap-southeast-1.amazonaws.com/993171523991/my-queue-1";
//var queueURL2 = "https://sqs.ap-southeast-1.amazonaws.com/993171523991/my-queue-2";

var event = {
    [
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-12-17",
    "valueDate": "2021-12-21",
    "transactionDescription": "COLD STORAGE-EASTWOOD",
    "transactionReferenceId": "900234005",
    "transactionAmount": "48098.65",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-08-12",
    "transactionCode": "1111",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-12-01",
    "valueDate": "2021-12-04",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234006",
    "transactionAmount": "35097",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-08-01",
    "transactionCode": "4090",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-11-01",
    "valueDate": "2021-11-03",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234007",
    "transactionAmount": "34635",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-08-01",
    "transactionCode": "3409",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-10-01",
    "valueDate": "2021-10-02",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234008",
    "transactionAmount": "8735",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-07-01",
    "transactionCode": "1409",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-09-01",
    "valueDate": "2021-09-05",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234009",
    "transactionAmount": "1237",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-07-01",
    "transactionCode": "2509",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-08-01",
    "valueDate": "2021-08-06",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234010",
    "transactionAmount": "56735",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-06-01",
    "transactionCode": "999",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-07-01",
    "valueDate": "2021-07-03",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234011",
    "transactionAmount": "5435",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-06-01",
    "transactionCode": "2500",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-06-17",
    "valueDate": "2021-06-21",
    "transactionDescription": "COLD STORAGE-EASTWOOD",
    "transactionReferenceId": "900234012",
    "transactionAmount": "7835",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-05-31",
    "transactionCode": "2367",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-05-02",
    "valueDate": "2021-05-05",
    "transactionDescription": "APPLE SOUTH ASIA PTE LTD",
    "transactionReferenceId": "900234013",
    "transactionAmount": "9035",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-05-02",
    "transactionCode": "1236",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-04-02",
    "valueDate": "2021-04-06",
    "transactionDescription": "ANNUAL MEMBERSHIP FEE",
    "transactionReferenceId": "900234014",
    "transactionAmount": "3500",
    "currency": "INR",
    "transactionType": "DEBIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-05-02",
    "transactionCode": "530",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-03-02",
    "valueDate": "2021-03-06",
    "transactionDescription": "BILLED FINANCE CHARGES",
    "transactionReferenceId": "900234015",
    "transactionAmount": "111",
    "currency": "INR",
    "transactionType": "CREDIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-05-02",
    "transactionCode": "409",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  },
  {
    "accountNumber": "4146XXX6XXXXXXX1219",
    "transactionDate": "2021-02-02",
    "valueDate": "2021-02-07",
    "transactionDescription": "GST ON ANNUAL MEMBERSHIP FEE",
    "transactionReferenceId": "900234016",
    "transactionAmount": "35",
    "currency": "INR",
    "transactionType": "CREDIT",
    "transactionStatus": "BILLED",
    "transactionPostingDate": "2021-05-02",
    "transactionCode": "12361",
    "eligibleForEqualPaymentPlan": "ELIGIBLE",
    "merchantName": "AAA"
  }
]
}
// For Standard Queue
exports.handler =   function(event, context, callback)  {




/*
    var params = {
         AttributeNames: [
            "SentTimestamp"
         ],
         MaxNumberOfMessages: 10,
         MessageAttributeNames: [
            "All"
         ],
         QueueUrl: queueURL2,
         VisibilityTimeout: 15,
         WaitTimeSeconds: 0
    };
 sqs.receiveMessage(params, function (err, data) {
   if (err) {
        callback(err, null);
   } else {

    let messageData = JSON.stringify(data.Messages[0].Body);
  
  
 const decipher = crypto.createDecipheriv(algorithm, key, iv);

let decryptedData = decipher.update(messageData, "hex", "utf-8");

decryptedData += decipher.final("utf8");

      
      let decrypttext = decryptedData;
          
   
  */
    let response={
     
     "Message" :  JSON.stringify(event)

    };     
   
      callback(null, response);
/*

   }
    
 });
 
 */
   };


       
  
    

   
    

  //let queueRes =  await sqs.receiveMessage(params).promise();
    
  
 




